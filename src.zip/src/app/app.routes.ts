import { Routes } from '@angular/router';
import { AddPersonComponent } from './add-person/add-person.component';

export const routes: Routes = [
    {path:"addPerson", component:AddPersonComponent}
];
